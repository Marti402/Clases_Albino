def lee_list(*fic_list):
	lista = []
	for fitxer in fic_list:
		with open(fitxer, "rt") as fp_list:
			lista += [linea.strip() for linea in fp_list]

	return lista

leeLis = lee_list

def path_name(nom_dir, nom_fit, extension):
	return nom_dir + '/' + nom_fit + '.' + extension

pathName = path_name